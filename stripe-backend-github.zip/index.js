const express = require("express");
const Stripe = require("stripe");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

app.post("/create-checkout-session", async (req, res) => {
  try {
    const { quantity, format, shipping } = req.body;

    // Tarifs en centimes
    const prices = { A6: 250, A5: 400, A4: 600, A3: 1000 };
    const unitPrice = prices[format] || prices.A4;
    const shippingCents = Math.round((parseFloat(shipping) || 0) * 100);

    // Préparer les items
    const lineItems = [];

    // Planche DTF
    lineItems.push({
      price_data: {
        currency: "eur",
        product_data: {
          name: `${quantity}× Planche DTF ${format}`
        },
        unit_amount: unitPrice
      },
      quantity
    });

    // Frais de port
    if (shippingCents > 0) {
      lineItems.push({
        price_data: {
          currency: "eur",
          product_data: { name: "Frais de port" },
          unit_amount: shippingCents
        },
        quantity: 1
      });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: "https://sublims-dtf.com/",
      cancel_url: "https://sublims-dtf.com/"
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("Error creating Stripe session:", err);
    res.status(500).json({ error: "Échec de la création de la session Stripe" });
  }
});

app.get("/", (_req, res) => res.send("Stripe backend is up!"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));